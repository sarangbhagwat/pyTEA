# TEAmod
Modules to enable techno-economic analysis (TEA) in Python.
